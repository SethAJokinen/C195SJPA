package Controller;

import Helper.JDBC;
import Model.Appointment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ResourceBundle;

public class ContactScheduleController implements Initializable {
    ObservableList<Appointment> appointments = FXCollections.observableArrayList();

    @FXML
    private TableView<Appointment> ContactScheduleView;

    @FXML
    private TableColumn<Appointment, Integer> contactIDCol;

    @FXML
    private ToggleGroup ReportGroup;

    @FXML
    private RadioButton TBDradioButton;

    @FXML
    private TableColumn<Appointment, Integer> appointmentID;

    @FXML
    private RadioButton contactScheduleRadioButton;

    @FXML
    private TableColumn<Appointment, Integer> custIDCol;

    @FXML
    private TableColumn<Appointment, String> descriptionCol;

    @FXML
    private TableColumn<Appointment, Timestamp> endCol;

    @FXML
    private RadioButton monthTypeRadioButton;

    @FXML
    private TableColumn<Appointment, Timestamp> startCol;

    @FXML
    private TableColumn<Appointment, String> titleCol;

    @FXML
    private TableColumn<Appointment, String> typeCol;

    /**
     *
     * @param event By clicking on this radiobutton, you will switch to the updateTracker table view.
     * @throws IOException
     */
    @FXML
    void OnActionSwitchToReport3(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((RadioButton) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/UpdateTracker.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event By clicking on radiobutton, you will switch to the monthly report by type table view.
     * @throws IOException
     */
    @FXML
    void onActionSwitchViewsToMonthly(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((RadioButton) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/Reports.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event Clicking this button will switch your screen to the appointment menu.
     * @throws IOException
     */
    @FXML
    void onActionToAppointments(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/AppointmentMenu.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event This button switches you back to the customer record.
     * @throws IOException
     */
    @FXML
    void onActionToCustomerRecords(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/CustomerMenu.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * This will initialize the appointments observableList with appointments from the appointments table via SELECT query.
     * Also,  initializes the tableview with appointment objects.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointments.clear();
        try {
            JDBC.makePreparedStatement("SELECT * FROM appointments", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                Appointment appointment = new Appointment(rs.getInt("Appointment_ID"), rs.getString("Title"), rs.getString("Description"),
                        rs.getString("Location"), rs.getString("Type"), rs.getTimestamp("Start"), rs.getTimestamp("End"), rs.getTimestamp("Create_Date"),
                        rs.getString("Created_By"), rs.getTimestamp("Last_Update"), rs.getString("Last_Updated_By"), rs.getInt("Customer_ID")
                        , rs.getInt("User_ID"), rs.getInt("Contact_ID"));

                appointments.add(appointment);
            }
        } catch (SQLException sqlException) {
            System.out.println(sqlException.getMessage());
        }
        ContactScheduleView.setItems(appointments);

        contactIDCol.setCellValueFactory(new PropertyValueFactory<>("contactID"));
        appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        custIDCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
    }
}
