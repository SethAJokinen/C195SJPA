package Controller;

import Helper.DataManager;
import Helper.JDBC;
import Helper.SwitchScenes;
import Helper.TimeZoneConverter;
import Model.Appointment;
import Model.Contact;
import Model.Customer;
import Model.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.*;
import java.util.Optional;
import java.util.ResourceBundle;

public class AddAppointmentFormController implements Initializable {
    ObservableList<Contact> contactList = FXCollections.observableArrayList();
    ObservableList<Appointment> appointmentsList = FXCollections.observableArrayList();
    ObservableList<User> userList = FXCollections.observableArrayList();
    ObservableList<Customer> customerList = FXCollections.observableArrayList();

    @FXML
    private TextField AppointmentID;

    @FXML
    private ComboBox<Contact> ContactSelection;

    @FXML
    private TextField Description;

    @FXML
    private TextField Location;

    @FXML
    private TextField Type;

    @FXML
    private TextField custID;

    @FXML
    private TextField endDateAndTime;

    @FXML
    private TextField startDateAndTime;

    @FXML
    private TextField title;

    @FXML
    private TextField userID;

    /**
     *
     * @param event This cancels out of the add appointment form and returns to the AppointmentMenu
     *              Will check for confirmation first.
     * @throws IOException thrown if an IOException is reached
     */
    @FXML
    void onActionCancel(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you certain you wish to cancel? This item will not be added.");
        Optional<ButtonType> result = alert.showAndWait();

        if(result.get() == ButtonType.OK) {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Object scene = FXMLLoader.load(getClass().getResource("/View/AppointmentMenu.fxml"));
            stage.setScene(new Scene((Parent) scene));
            stage.show();
        }

    }

    /**
     *
     * @param event This button will cause the method to attempt to save the information in the fields and combo boxes to the database, however,
     *  if there are any fields, including the time fields that possess inappropriate information such as text in the ID fields or TimeStamps with an
     *  incorrect format, the button will instead throw an error.
     *  This method also holds two examples of <b>lambda expressions</b>
     *              The first of which is a timezone converter which converts local to EST to check if the time is in business hours.
     *              This makes it easy to convert multiple times, StartDateAndTime and EndDateAndTime to EST to check for business hours.
     *              The second of which switches the screens after the item updates back to the appointment screen.
     *              This one offers me modular ways that I can choose to change my screen.
     */
    @FXML
    void onActionSave(ActionEvent event) {

        if (ContactSelection.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Combo boxes must have a selection!");
            alert.showAndWait();
            return;
        }

        try {
            String Title = title.getText();
            String description = Description.getText();
            String location = Location.getText();
            String type = Type.getText();
          //  Timestamp startDateAndTime = Timestamp.valueOf(this.startDateAndTime.getText());
          //  Timestamp endDateAndtime = Timestamp.valueOf(this.endDateAndTime.getText());

            String startParse = startDateAndTime.getText().replace(" ", "T");
            String endParse = endDateAndTime.getText().replace(" ", "T");
            LocalDateTime startDateAndTime = LocalDateTime.parse(startParse);
            LocalDateTime endDateAndtime = LocalDateTime.parse(endParse);
           // Timestamp SDaT = startDateAndTime;
           // Timestamp EDaT = endDateAndtime;

            ZoneId localZoneID = ZoneId.of(ZoneId.systemDefault().getId());

            TimeZoneConverter timeConverterStart = zoneId -> {
                ZonedDateTime localZoneDateTime =  ZonedDateTime.of(startDateAndTime, zoneId);
                Instant localZDTtoInstant = localZoneDateTime.toInstant();
                ZonedDateTime localInstantToEST = localZDTtoInstant.atZone(ZoneId.of("America/New_York"));
                System.out.println(localInstantToEST.toLocalDateTime());
                return localInstantToEST.toLocalDateTime();
            };

            TimeZoneConverter timeConverterEnd = zoneId -> {
                ZonedDateTime localZoneDateTime =  ZonedDateTime.of(endDateAndtime, zoneId);
                Instant localZDTtoInstant = localZoneDateTime.toInstant();
                ZonedDateTime localInstantToEST = localZDTtoInstant.atZone(ZoneId.of("America/New_York"));
                return localInstantToEST.toLocalDateTime();
            };

            if((timeConverterStart.timeConversion(localZoneID).toLocalTime()).isBefore(LocalTime.of(8, 00))) {
                Alert alert = new Alert(Alert.AlertType.ERROR,"You cannot schedule an appointment before 8:00am EST");
                alert.showAndWait();
                return;
            }

            if ((timeConverterStart.timeConversion(localZoneID).toLocalTime()).isAfter(LocalTime.of(22, 00)))
            {

                Alert alert = new Alert(Alert.AlertType.ERROR,"You cannot schedule an appointment after 10:00pm EST");
                alert.showAndWait();
                return;
            }

            if((timeConverterEnd.timeConversion(localZoneID).toLocalTime()).isBefore(LocalTime.of(8, 00))) {
                Alert alert = new Alert(Alert.AlertType.ERROR,"You cannot schedule an appointment before 8:00am EST");
                alert.showAndWait();
                return;
            }
            else if ((timeConverterEnd.timeConversion(localZoneID).toLocalTime()).isAfter(LocalTime.of(22, 00)))
            {

                Alert alert = new Alert(Alert.AlertType.ERROR,"You cannot schedule an appointment after 10:00pm EST");
                alert.showAndWait();
                return;
            }
            else if ((timeConverterEnd.timeConversion(localZoneID).toLocalTime()).isBefore(startDateAndTime.toLocalTime()))
            {
                //System.out.println("The time entered is: " + startDateAndTime);
                //System.out.println("The converted time in EST is: " + timeConverterEnd.timeConversion(localZoneID).toLocalTime());
                Alert alert = new Alert(Alert.AlertType.ERROR,"You cannot schedule an end time before the start time!");
                alert.showAndWait();
                return;
            }

            //FixMe: This is not comparing times correctly. Also, times are posting literally to the database as UTC, but times displayed in tables are with offset subtracted from the entered times.
            for (Appointment appointment : appointmentsList) {
                if (startDateAndTime.isAfter(appointment.getStartTime().toLocalDateTime()) && startDateAndTime.isBefore(appointment.getEndTime().toLocalDateTime())) {
                    System.out.println( "The start time" + startDateAndTime + " conflicts with " + appointment.getStartTime() + " or " + appointment.getEndTime());
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You cannot schedule an appointment during another appointment!");
                    alert.showAndWait();
                    return;

                }
            }

            for(Appointment appointment: appointmentsList) {
                if(endDateAndtime.isAfter(appointment.getStartTime().toLocalDateTime()) && endDateAndtime.isBefore(appointment.getEndTime().toLocalDateTime()))
                {
                    System.out.println("The end time" + endDateAndtime + " conflicts with " + appointment.getStartTime() + " or " + appointment.getEndTime());
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You cannot schedule an appointment during another appointment!");
                    alert.showAndWait();
                    return;
                }
            }
            for(Appointment appointment: appointmentsList) {
                if(appointment.getStartTime().toLocalDateTime().isBefore(endDateAndtime) && appointment.getEndTime().toLocalDateTime().isAfter(startDateAndTime))
                {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You cannot schedule an appointment during another appointment!");
                    alert.showAndWait();
                    return;
                }
            }

            if(endDateAndtime.isBefore(startDateAndTime) || endDateAndtime.isEqual(startDateAndTime)) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "You cannot schedule an end time before or at the same time as a start time!");
                alert.showAndWait();
                return;
            }

            for(Appointment appoint: appointmentsList) {
                if(appoint.getStartTime().toLocalDateTime().isEqual(startDateAndTime) || appoint.getStartTime().toLocalDateTime().isEqual(endDateAndtime)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You cannot schedule a start time at the same time as another appointment.");
                    alert.showAndWait();
                    return;
                }
                if(appoint.getEndTime().toLocalDateTime().isEqual(startDateAndTime) || appoint.getEndTime().toLocalDateTime().isEqual(endDateAndtime)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You cannot schedule an end time at the same time as another appointment.");
                    alert.showAndWait();
                    return;
                }
            }

            String createdBy = DataManager.userName;
            String lastUpdatedBy = DataManager.userName;
            int custID = Integer.valueOf(this.custID.getText());
            int userID = Integer.valueOf(this.userID.getText());
            int contactID = ContactSelection.getSelectionModel().getSelectedItem().getContactID();

            //FIXME: Not the alert that I want.
            int counter  = 0;
            for(Customer customer : customerList) {

              if (custID == customer.getCustomerID()) {

                    break;
                }
                else if (!(counter ==  customerList.size() - 1)){
                    counter ++;
                }
                else {

                  Alert alert = new Alert (Alert.AlertType.ERROR, "You must enter a valid customer ID for a current customer!");
                  alert.showAndWait();
                  return;
              }
            }

            int userCount = 0;
            for (User user : userList) {
                if (userID == user.getUserID()) {
                    break;
                }
                else if (!(userCount == userList.size() - 1)){
                    userCount++;
                    continue;
                } else {
                    Alert alert = new Alert (Alert.AlertType.ERROR, "You must enter a valid user ID for a current user!");
                    alert.showAndWait();
                    return;
                }
            }



            JDBC.makePreparedStatement("INSERT INTO appointments" +
                            "(Title, Description, Location, Type, Start, End, Create_Date, Created_By," +
                            " Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID)"
                    + "VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, NOW(), ?, ?, ?, ?)"
             //               + "VALUES (" + "\"" + Title + "\"," + "\"" + description + "\"," + "\"" + location + "\"," + "\"" +type + "\","
             //       + "\"" + startDateAndTime + "\"," + "\"" + endDateAndtime + "\"," + "NOW()," + "\"" + createdBy + "\"," + "NOW()," + "\""+lastUpdatedBy + "\","  + custID
             //       + "," + userID + "," + contactID + ")"
                    , JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.setString(1,Title);
            ps.setString(2, description);
            ps.setString(3, location);
            ps.setString(4, type);
            ps.setTimestamp(5, Timestamp.valueOf(startDateAndTime));
            ps.setTimestamp(6, Timestamp.valueOf(endDateAndtime));
            ps.setString(7, createdBy);
            ps.setString(8,lastUpdatedBy);
            ps.setInt(9,custID);
            ps.setInt(10,userID);
            ps.setInt(11, contactID);

            ps.executeUpdate();

            SwitchScenes changeScenes = s -> {
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Object scene = FXMLLoader.load(getClass().getResource(s));
                stage.setScene(new Scene((Parent) scene));
                stage.show();
            };

            changeScenes.switchScreen("/View/AppointmentMenu.fxml");

        } catch (SQLException | IOException | IllegalArgumentException e ) {
            Alert alert = new Alert(Alert.AlertType.ERROR, e.getMessage());
            alert.showAndWait();
            return;
        }

    }


    /**
     * This method provides objects for four different observable lists by extracting the result sets from four different SELECT statements.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            JDBC.makePreparedStatement("SELECT * FROM contacts", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                Contact contact = new Contact(rs.getInt("Contact_ID"), rs.getString("Contact_Name"), rs.getString("Email"));
                contactList.add(contact);
                System.out.println(contact.getContactName());
            }

        }catch(SQLException sql) {
            System.out.println(sql.getMessage());
        }

        try {
            JDBC.makePreparedStatement("SELECT * FROM appointments", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                Appointment appointment = new Appointment(rs.getInt("Appointment_ID"), rs.getString("Title"), rs.getString("Description"),
                        rs.getString("Location"), rs.getString("Type"), rs.getTimestamp("Start"), rs.getTimestamp("End"), rs.getTimestamp("Create_Date"),
                        rs.getString("Created_By"), rs.getTimestamp("Last_Update"), rs.getString("Last_Updated_By"), rs.getInt("Customer_ID")
                        , rs.getInt("User_ID"), rs.getInt("Contact_ID"));

                appointmentsList.add(appointment);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        try {
            customerList.clear();
            JDBC.makePreparedStatement("SELECT * FROM customers", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Customer customer = new Customer(rs.getInt("Customer_ID"), rs.getString("Customer_Name"),
                        rs.getString("Address"), rs.getString("Postal_Code"), rs.getString("Phone"),
                        rs.getTimestamp("Create_Date"), rs.getString("Created_By"),
                        rs.getTimestamp("Last_Update"), rs.getString("Last_Updated_By"),
                        rs.getInt("Division_ID"));
                //FixME, this is where I wanted to fix it!

                customerList.add(customer);
            }


        } catch (SQLException sql) {
            System.out.println("Error: " + sql.getMessage());
        }

        try {
            JDBC.makePreparedStatement("SELECT * FROM users", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                User user = new User(rs.getInt("User_ID"), rs.getString("User_Name"), rs.getString("Password"),
                        rs.getTimestamp("Create_Date"), rs.getString("Created_By"), rs.getTimestamp("Last_Update"),
                        rs.getString("Last_Updated_By"));
                userList.add(user);
                // System.out.println("Here are the user names:" + user.getUserName());

            }

        }catch (SQLException sql) {
            System.out.println("ERROR DETECTED: " + sql.getStackTrace());
        }

        ContactSelection.setItems(contactList);

    }
}
