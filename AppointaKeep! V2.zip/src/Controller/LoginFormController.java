package Controller;

import Helper.DataManager;
import Helper.JDBC;
import Helper.SwitchScenes;
import Model.Appointment;
import Model.User;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.ResourceBundle;

@SuppressWarnings("CanBeFinal")
public class LoginFormController implements Initializable {
    Parent parent;
    Scene scene;

    public static ObservableList<User> userList = FXCollections.observableArrayList();
    ObservableList<Appointment> appointments = FXCollections.observableArrayList();



    @FXML
    private Label localeField;

    @FXML
    private Button logOnButton;

    @FXML
    private Label promptLabel;

    @FXML
    private Label passwordLabel;

    @FXML
    private Label userNameLabel;

    @FXML
    private TextField passwordField;

    @FXML
    private TextField usernameField;

    public LoginFormController() throws IOException {
    }


    /**
     *
     * @param event Upon clicking log-in, this will check the entered credentials, reject the user if improper credentials are entered and will record each successful and
     *              failed log-in attempt for each registered user. In addition, a successful log in attempt will inform the user of whether an appointment is due soon.
     * @throws SQLException
     * @throws IOException
     */
    @FXML
    void onActionLogIn(ActionEvent event) throws SQLException, IOException {
       Locale.setDefault(Locale.FRENCH);
        ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
        User user = null;
        boolean userFound = false;
        String fileName = "src/login_activity.txt";
        File file = new File(fileName);
        FileWriter Fwriter = new FileWriter(fileName, true);
        PrintWriter Pwriter = new PrintWriter(Fwriter);

        for (User users : userList) {
            if (users.getUserName().equals(usernameField.getText())) {
                userFound = true;
                user = users;
            }
        }


        if(!userFound) {

            Alert alert = new Alert(Alert.AlertType.ERROR, rb.getString("User by") + "  \"" + usernameField.getText() + "\" "  + rb.getString("is not found!"));
            alert.showAndWait();
            return;
        }

        if (passwordField.getText().equals(user.getPassword())) {
            DataManager.userName = user.getUserName();
            System.out.println("User has access!");
            Pwriter.println(user.getUserName() + " has successfully logged in at " + LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
            //FIXME: Lambda # 1 (Doesn't really need fixing, just making this easier to find.)

            int counter = 0;
            for(Appointment appointment: appointments) {
                if (LocalDateTime.now().isAfter(appointment.getStartTime().toLocalDateTime().minusMinutes(15))
                    && LocalDateTime.now().isBefore(appointment.getStartTime().toLocalDateTime())) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "You have an appointment starting soon! \n"
                + "Appointment ID: "+ appointment.getAppointmentID() + "\nAppointment start time: " + appointment.getStartTime());
                alert.showAndWait();
                System.out.println("first branch");
                break;
            } else if (!(counter == appointments.size() - 1)) {
                counter++;
                System.out.println(counter);
            } else {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "No appointments at this time.");
                alert.showAndWait();
                System.out.println("third branch");
            }
            }


            SwitchScenes changeScenes = s -> {
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Object scene = FXMLLoader.load(getClass().getResource(s));
                stage.setScene(new Scene((Parent) scene));
                stage.show();
                return;
            };

            changeScenes.switchScreen("/View/CustomerMenu.fxml");


                }
        else {
            System.out.println("User failed to log in!");
            Pwriter.println(user.getUserName() + " has failed to log in at " + LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
            Alert alert = new Alert(Alert.AlertType.ERROR, rb.getString("Incorrect Password!"));
            alert.showAndWait();

        }
        Pwriter.close();



    }

    /**
     * In addition to populating observable lists with User and AppointmentData, this also uses resource bundles to change the language of all of the text-fields
     *     and labels on the form.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       Locale.setDefault(Locale.FRENCH);
        ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());



        try {
            JDBC.makePreparedStatement("SELECT * FROM users", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                User user = new User(rs.getInt("User_ID"), rs.getString("User_Name"), rs.getString("Password"),
                        rs.getTimestamp("Create_Date"), rs.getString("Created_By"), rs.getTimestamp("Last_Update"),
                        rs.getString("Last_Updated_By"));
                userList.add(user);
               // System.out.println("Here are the user names:" + user.getUserName());

            }

        }catch (SQLException sql) {
            System.out.println("ERROR DETECTED: " + sql.getStackTrace());
        }
        try {
            JDBC.makePreparedStatement("SELECT * FROM appointments", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                Appointment appointment = new Appointment(rs.getInt("Appointment_ID"), rs.getString("Title"), rs.getString("Description"),
                        rs.getString("Location"), rs.getString("Type"), rs.getTimestamp("Start"), rs.getTimestamp("End"), rs.getTimestamp("Create_Date"),
                        rs.getString("Created_By"), rs.getTimestamp("Last_Update"), rs.getString("Last_Updated_By"), rs.getInt("Customer_ID")
                        , rs.getInt("User_ID"), rs.getInt("Contact_ID"));

                appointments.add(appointment);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        if (Locale.getDefault().equals(Locale.FRENCH)) {
            promptLabel.setText(rb.getString("Please provide your user name and password:") + LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
            userNameLabel.setText(rb.getString("Username:"));
            passwordLabel.setText(rb.getString("Password:"));
            logOnButton.setText(rb.getString("Log in"));

        }

            localeField.setText(ZoneId.systemDefault() + " " + Timestamp.valueOf(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS)));


    }
}
