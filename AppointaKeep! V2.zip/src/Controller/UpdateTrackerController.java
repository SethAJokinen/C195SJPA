package Controller;

import Helper.JDBC;
import Model.UpdateTrackerReports;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ResourceBundle;

public class UpdateTrackerController implements Initializable {
    ObservableList<UpdateTrackerReports> trackerReports = FXCollections.observableArrayList();
    @FXML
    private TableColumn<UpdateTrackerReports, String> LastUpdatedByCol;

    @FXML
    private ToggleGroup ReportGroup;

    @FXML
    private RadioButton TBDradioButton;

    @FXML
    private TableView<UpdateTrackerReports> UpdateTrackerView;

    @FXML
    private TableColumn<UpdateTrackerReports, Integer> appointmentIDCol;

    @FXML
    private RadioButton contactScheduleRadioButton;

    @FXML
    private TableColumn<UpdateTrackerReports, Integer> custIDCol;

    @FXML
    private TableColumn<UpdateTrackerReports, Timestamp> custLastUpdateCol;

    @FXML
    private TableColumn<UpdateTrackerReports, String> lastUpdatedByCustCol;

    @FXML
    private RadioButton monthTypeRadioButton;

    @FXML
    private TableColumn<UpdateTrackerReports, Timestamp> updateTimeCol;

    /**
     *
     * @param event Clicking on this button with switch you to the contact report screen.
     * @throws IOException
     */
    @FXML
    void OnActionSwitchtoContact(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((RadioButton) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/ContactSchedule.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event Clicking on this button will switch you to the Monthly report screen.
     * @throws IOException
     */
    @FXML
    void onActionSwitchToMonthlyReport(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((RadioButton) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/Reports.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }

    /**
     *
     * @param event This will switch your view to the appointments menu.
     * @throws IOException
     */
    @FXML
    void onActionToAppointments(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/AppointmentMenu.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event This will switch your view to the customer records screen.
     * @throws IOException
     */
    @FXML
    void onActionToCustomerRecords(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/CustomerMenu.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * This initializes the table with information from a UppdateTrackerReports object which is itself populated with a SQL SELECT statement.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            JDBC.makePreparedStatement("SELECT Appointment_ID, a.Last_Updated_By, a.Last_Update, c.Customer_ID, c.Last_Updated_By, c.Last_Update\n" +
                    "FROM appointments a\n" +
                    "INNER JOIN customers c ON a.Customer_ID = c.Customer_ID;", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                UpdateTrackerReports UTR = new UpdateTrackerReports(rs.getInt("Appointment_ID"), rs.getString("a.Last_Updated_By"),
                        rs.getTimestamp("a.Last_Update"), rs.getInt("c.Customer_ID"), rs.getString("c.Last_Updated_By"),
                        rs.getTimestamp("c.Last_Update"));
                trackerReports.add(UTR);
                System.out.println("Here are the UTR reports: " + UTR.getAppointmentID() + " " + UTR.getAppointUpdateBy() + " " + UTR.getCustID() + " " + UTR.getCustUpdateBy());
            }
        } catch (SQLException sqlException) {
            System.out.println(sqlException.getMessage());;
        }

        UpdateTrackerView.setItems(trackerReports);

        appointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        LastUpdatedByCol.setCellValueFactory(new PropertyValueFactory<>("appointUpdateBy"));
        updateTimeCol.setCellValueFactory(new PropertyValueFactory<>("appointUpdateTime"));
        custIDCol.setCellValueFactory(new PropertyValueFactory<>("custID"));
        lastUpdatedByCustCol.setCellValueFactory(new PropertyValueFactory<>("custUpdateBy"));
        custLastUpdateCol.setCellValueFactory(new PropertyValueFactory<>("custUpdateTime"));

    }
}
