package Controller;

import Model.CustomerReport;
import Helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ReportsController implements Initializable {
    ObservableList<CustomerReport> appointmentReportList = FXCollections.observableArrayList();

    @FXML
    private TableColumn<CustomerReport, Integer> numByTypeCol;

    @FXML
    private ToggleGroup ReportGroup;

    @FXML
    private RadioButton TBDradioButton;

    @FXML
    private RadioButton contactScheduleRadioButton;

    @FXML
    private TableColumn<CustomerReport, Integer> customerCol;

    @FXML
    private TableColumn<CustomerReport, String> monthCol;

    @FXML
    private TableView<CustomerReport> appointmentReport;

    @FXML
    private RadioButton monthTypeRadioButton;

    @FXML
    private TableColumn<CustomerReport, String> typeCol;

    /**
     *
     * @param event Pressing this button will switch the view to the Update Tracker
     * @throws IOException
     */
    @FXML
    void OnActionSwitchToReport3(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((RadioButton) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/UpdateTracker.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event This will switch the view to the contact Report form.
     * @throws IOException
     */
    @FXML
    void OnActionSwitchtoContactReports(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((RadioButton) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/ContactSchedule.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * This will switch the view back to the appointments screen.
     * @param event
     * @throws IOException
     */
    @FXML
    void onActionToAppointments(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/AppointmentMenu.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event This will switch the view to the customer records screen.
     * @throws IOException
     */
    @FXML
    void onActionToCustomerRecords(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/CustomerMenu.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * This initializes the tableview with the CustomerReport objects which display information from the below SQL statement.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointmentReportList.clear();

        try {
            JDBC.makePreparedStatement("SELECT Customer_ID, Type, Start, count(*)\n" +
                    " FROM appointments\n" +
                    " GROUP BY Customer_ID, Type;", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                CustomerReport custReport = new CustomerReport(rs.getInt("Customer_ID"), rs.getString("Type"), rs.getTimestamp("Start").toLocalDateTime().getMonth(),
                     rs.getInt("count(*)"));
                appointmentReportList.add(custReport);
            }

        } catch (SQLException sqlException) {
            System.out.println(sqlException.getMessage());
        }

        appointmentReport.setItems(appointmentReportList);

        customerCol.setCellValueFactory(new PropertyValueFactory("custID"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        monthCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        numByTypeCol.setCellValueFactory(new PropertyValueFactory<>("count"));
    }
}
