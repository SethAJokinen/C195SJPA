package Controller;

import Helper.DataManager;
import Helper.JDBC;
import Helper.SwitchScenes;
import Model.Countries;
import Model.Customer;
import Model.FirstLevelDivisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class UpdateCustomerFormController implements Initializable {

    ObservableList<Countries> countryList = FXCollections.observableArrayList();
    ObservableList<FirstLevelDivisions> divisionList = FXCollections.observableArrayList();
    ObservableList<FirstLevelDivisions> filteredDivisionList = FXCollections.observableArrayList();

    @FXML
    private ComboBox<Countries> CountrySelection;

    @FXML
    private ComboBox<FirstLevelDivisions> FirstLevelDivision;

    @FXML
    private TextField address;

    @FXML
    private TextField customerID;

    @FXML
    private TextField customerName;

    @FXML
    private TextField phoneNumber;

    @FXML
    private TextField postalCode;

    /**
     * This method will populate the divisions combobox with the relevant information according to what country is selected.
     * @param event triggers when a selection is made from the country combo box.
     * @throws SQLException if a SQLException is reached.
     */
    @FXML
    void OnActionSelectionMade(ActionEvent event) throws SQLException {


        filteredDivisionList.clear();
        FirstLevelDivision.getSelectionModel().selectFirst();

        for (FirstLevelDivisions division: divisionList) {
            if (division.getCountryID() == CountrySelection.getValue().getCountryID()) {
                filteredDivisionList.add(division);
            }
        }
        FirstLevelDivision.setItems(filteredDivisionList);


    }
    /**
     * This will cancel out of the add customer form. However, this will check for confirmation first before doing so.
     * @param event
     * @throws IOException
     */
    @FXML
    void onActionCancel(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you certain you wish to cancel? This item will not be added.");
        Optional<ButtonType> result = alert.showAndWait();

        if(result.get() == ButtonType.OK) {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Object scene = FXMLLoader.load(getClass().getResource("/View/CustomerMenu.fxml"));
            stage.setScene(new Scene((Parent) scene));
            stage.show();
        }
    }
    /**
     *
     * @param event This button will save the customer to the customer table in the database. This method does have checking to make sure that
     *              the information is valid before proceeding.
     *
     */

    @FXML
    void onActionSave(ActionEvent event) {
        try {
            if (CountrySelection.getSelectionModel().getSelectedItem() == null || FirstLevelDivision.getSelectionModel().getSelectedItem() == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "The combo boxes must hold a value!");
                alert.showAndWait();
                return;
            }


            String customerName = this.customerName.getText();
            String address = this.address.getText();
            String phone = phoneNumber.getText();
            String post = postalCode.getText();
            int FLD = FirstLevelDivision.getValue().getDivision_id();
            String createdBy = DataManager.userName;
            String lastUpdatedBy = DataManager.userName;


            JDBC.makePreparedStatement("UPDATE customers SET " +
                    "Customer_Name = " + "\"" + customerName + "\",  " + "Address = " + "\"" + address + "\", " + "Postal_Code = " + "\"" + post + "\", "
                    + "Phone = " + "\"" + phone + "\", " + "Last_Update = " + "NOW(), Last_Updated_By = "  + "\", " + lastUpdatedBy + "\", " + "Division_ID = " + FLD
                    + " WHERE Customer_ID = " + (Integer.valueOf(customerID.getText()))
                    , JDBC.getConnection());

            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.executeUpdate();

            SwitchScenes changeScenes = s -> {
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Object scene = FXMLLoader.load(getClass().getResource(s));
                stage.setScene(new Scene((Parent) scene));
                stage.show();
                return;
            };

            changeScenes.switchScreen("/View/CustomerMenu.fxml");

            //FIXME: Try for some alerts!

        }catch (SQLException | IOException sql) {
            Alert alert = new Alert(Alert.AlertType.ERROR,  "Error: " + sql.getMessage());
            alert.showAndWait();
            return;
        }
    }

    /**
     *
     * @param customer This receives a customer object to populate certain text fields with.
     * @param FLD This receives a FirstLeveLDivisions object to populate the combo box.
     * @param countries This receives a countries object to populate the combo box.
     */
    public void recieveCustomerInfo(Customer customer, FirstLevelDivisions FLD, Countries countries) {
        customerID.setText(Integer.toString(customer.getCustomerID()));
        customerName.setText(customer.getCustomerName());
        postalCode.setText(customer.getPostalCode());
        phoneNumber.setText(customer.getPhoneNumber());
        address.setText(customer.getAddress());

        FirstLevelDivision.setValue(FLD);
        CountrySelection.setValue(countries);


    }
    /**
     * This initialize method will fill two observable lists with objects that are the result of SELECT statements from the countries, and divisions tables.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            JDBC.makePreparedStatement("SELECT * FROM countries", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Countries country = new Countries(rs.getInt("Country_ID"), rs.getString("Country"),
                        rs.getTimestamp("Create_Date"), rs.getString("Created_By"), rs.getTimestamp("Last_Update"),
                        rs.getString("Last_Updated_By"));
                countryList.add(country);
                DataManager.countriesList.add(country);
            }


        } catch (SQLException sql) {
            System.out.println("Error: " + sql.getMessage());
        }
        CountrySelection.setItems(countryList);


        try {
            JDBC.makePreparedStatement("SELECT * FROM first_level_divisions", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                FirstLevelDivisions divisions = new FirstLevelDivisions(rs.getInt("Division_ID"), rs.getString("Division"),
                        rs.getTimestamp("Create_Date"), rs.getString("Created_By"), rs.getTimestamp("Last_Update"),
                        rs.getString("Last_Updated_By"), rs.getInt("Country_ID"));
                divisionList.add(divisions);
            }


        } catch (SQLException sql) {
            System.out.println("Error: " + sql.getMessage());
        }

        FirstLevelDivision.setItems(divisionList);

    }

}
