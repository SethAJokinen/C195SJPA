package Controller;


import Helper.DataManager;
import Helper.JDBC;
import Model.Appointment;
import Model.Countries;
import Model.Customer;
import Model.FirstLevelDivisions;
import com.mysql.cj.x.protobuf.MysqlxCrud;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.util.Optional;
import java.util.ResourceBundle;

@SuppressWarnings("CanBeFinal")
public class CustomerMenuController implements Initializable {
        Parent parent;
        Scene scene;
       static ObservableList<Customer> customerList = FXCollections.observableArrayList();
       static ObservableList<FirstLevelDivisions> firstLevelDivisionsList = FXCollections.observableArrayList();
       static ObservableList<Countries> countriesList = FXCollections.observableArrayList();
       static ObservableList<Appointment> appointments = FXCollections.observableArrayList();


        @FXML
        private TableColumn<Customer, Integer> DivisionIdCol;

        @FXML
        private TableColumn<Customer, String> addressCol;

        @FXML
        private TableColumn<Customer, LocalDateTime> createDateCol;

        @FXML
        private TableColumn<Customer, String> createdByCol;

        @FXML
        private TableColumn<Customer, Integer> custIdCol;

        @FXML
        private TableColumn<Customer, String> custNameCol;

        @FXML
        private TableColumn<Customer, LocalDateTime> lastUpdateCol;

        @FXML
        private TableColumn<Customer, String> lastUpdatedByCol;

        @FXML
        private TableColumn<Customer, Integer> phoneCol;

        @FXML
        private TableColumn<Customer, Integer> postalCodeCol;

        @FXML
        private TableView<Customer> customerData;

    /**
     *
     * @param event Clicking this button will exit out of the application.
     */
    @FXML
        void OnActionLeaveApplication(ActionEvent event) { System.exit(0);
        }

    /**
     *
     * @param event Clicking on this button will send you to the appointments menu.
     * @throws IOException
     */
        @FXML
        void OnActionGoToAppointments(ActionEvent event) throws IOException {
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Object scene = FXMLLoader.load(getClass().getResource("/View/AppointmentMenu.fxml"));
                stage.setScene(new Scene((Parent) scene));
                stage.show();
        }

    /**
     *
     * @param event Clicking on this button will send you to the reports screen.
     * @throws IOException
     */
    @FXML
        void OnActionSwitchToReportView(ActionEvent event) throws IOException {

                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Object scene = FXMLLoader.load(getClass().getResource("/View/Reports.fxml"));
                stage.setScene(new Scene((Parent) scene));
                stage.show();

        }

    /**
     *
     * @param event Clicking on this button will send you to the add Customer screen.
     * @throws IOException
     */
        @FXML
        void onActionAdd(ActionEvent event) throws IOException {

                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Object scene = FXMLLoader.load(getClass().getResource("/View/AddCustomerForm.fxml"));
                stage.setScene(new Scene((Parent) scene));
                stage.show();
        }

    /**
     *
     * @param event Provided a selection has been made in the table view, this will send you to the update customer menu. Otherwise,
     *              it will throw an alert to let you know you need to throw an alert. This also passes information into the update customer menu fields.
     * @throws IOException
     */
        @FXML
        void onActionUpdate(ActionEvent event) throws IOException {

                if(customerData.getSelectionModel().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You need to make a selection from the table first!");
                    alert.showAndWait();
                    return;
                }
                DataManager.createDate = customerData.getSelectionModel().getSelectedItem().getCreateDate();

                 FXMLLoader loader = new FXMLLoader();
                 loader.setLocation(getClass().getResource("/View/UpdateCustomerForm.fxml"));
                 loader.load();
                 UpdateCustomerFormController UpdateCust = loader.getController();
                 FirstLevelDivisions FLD = null;
                 Countries country = null;

                 for(FirstLevelDivisions firstLevelDivisions : firstLevelDivisionsList){
                     if(firstLevelDivisions.getDivision_id() == customerData.getSelectionModel().getSelectedItem().getDivisionId()) {
                         FLD = firstLevelDivisions;
                     }
                 }

                 for(Countries countries: countriesList) {
                     if (countries.getCountryID() == FLD.getCountryID())
                         country = countries;
                 }

                 UpdateCust.recieveCustomerInfo(customerData.getSelectionModel().getSelectedItem(), FLD, country);

                 Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                 Parent scene = loader.getRoot();
                 stage.setScene(new Scene((Parent) scene));
                 stage.show();


        }

    /**
     *
     * @param event Provided a selection is made in the table, this method will ask for confirmation that you wish to delete a customer record
     *              upon agreeing, it will delete all appointments that were made for this customer before deleting the customer and displaying a message.
     * @throws SQLException
     */
        @FXML
        void OnActionDelete(ActionEvent event) throws SQLException {

            if(customerData.getSelectionModel().isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR,"You must make a selection from the table first!");
                alert.showAndWait();
                return;
            }

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you certain you wish to delete this customer record? \n" +
                    "This will also automatically delete appointments associated with this customer.");
            alert.setTitle("Confirmation Needed");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.get() == ButtonType.OK) {

                for (Customer customer : customerList) {
                    if (customer.getCustomerID() == (customerData.getSelectionModel().getSelectedItem().getCustomerID())) {
                        JDBC.makePreparedStatement("DELETE FROM APPOINTMENTS WHERE Customer_ID = " + customer.getCustomerID(), JDBC.getConnection());
                        PreparedStatement da = JDBC.getPreparedStatement();
                        da.executeUpdate();

                        Alert delAlert = new Alert(Alert.AlertType.INFORMATION, customer.getCustomerName() + " has been deleted successfully!");
                        delAlert.showAndWait();

                        JDBC.makePreparedStatement("DELETE FROM customers WHERE Customer_ID = " + customer.getCustomerID(),
                                JDBC.getConnection());
                        PreparedStatement ps = JDBC.getPreparedStatement();
                        ps.executeUpdate();
                        customerList.remove(customer);
                        customerData.refresh();
                    }
                }
            }

        }
        //FIXME: Potentially have a sendList method to send a Users observable list to another Controller.

    /**
     * This initialize method will make four SELECT statments to populate the above observableLists, in addition it will set the values of the
     * tableview.
     * @param url
     * @param resourceBundle
     */
    @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
            appointments.clear();

                try {
                    customerList.clear();
                        JDBC.makePreparedStatement("SELECT * FROM customers", JDBC.getConnection());
                        PreparedStatement ps = JDBC.getPreparedStatement();
                        ResultSet rs = ps.executeQuery();

                        while (rs.next()) {
                                Customer customer = new Customer(rs.getInt("Customer_ID"), rs.getString("Customer_Name"),
                                        rs.getString("Address"), rs.getString("Postal_Code"), rs.getString("Phone"),
                                        rs.getTimestamp("Create_Date"), rs.getString("Created_By"),
                                        rs.getTimestamp("Last_Update"), rs.getString("Last_Updated_By"),
                                        rs.getInt("Division_ID"));
                                //FixME, this is where I wanted to fix it!

                                customerList.add(customer);
                        }


                } catch (SQLException sql) {
                        System.out.println("Error: " + sql.getMessage());
                }

            try {
                JDBC.makePreparedStatement("SELECT * FROM first_level_divisions", JDBC.getConnection());
                PreparedStatement ps = JDBC.getPreparedStatement();
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    FirstLevelDivisions divisions = new FirstLevelDivisions(rs.getInt("Division_ID"), rs.getString("Division"),
                            rs.getTimestamp("Create_Date"), rs.getString("Created_By"), rs.getTimestamp("Last_Update"),
                            rs.getString("Last_Updated_By"), rs.getInt("Country_ID"));
                    firstLevelDivisionsList.add(divisions);
                }


            } catch (SQLException sql) {
                System.out.println("Error: " + sql.getMessage());
            }

            try {    JDBC.makePreparedStatement("SELECT * FROM countries", JDBC.getConnection());
                PreparedStatement ps = JDBC.getPreparedStatement();
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Countries country = new Countries(rs.getInt("Country_ID"), rs.getString("Country"),
                            rs.getTimestamp("Create_Date"), rs.getString("Created_By"),
                            rs.getTimestamp("Last_Update"),
                            rs.getString("Last_Updated_By"));
                    countriesList.add(country);
                }} catch (SQLException sql) {
                System.out.println("Error: " + sql.getMessage());}

            try {
                JDBC.makePreparedStatement("SELECT * FROM appointments", JDBC.getConnection());
                PreparedStatement ps = JDBC.getPreparedStatement();
                ResultSet rs = ps.executeQuery();

                while(rs.next()) {
                    Appointment appointment = new Appointment(rs.getInt("Appointment_ID"), rs.getString("Title"), rs.getString("Description"),
                            rs.getString("Location"), rs.getString("Type"), rs.getTimestamp("Start"), rs.getTimestamp("End"), rs.getTimestamp("Create_Date"),
                            rs.getString("Created_By"), rs.getTimestamp("Last_Update"), rs.getString("Last_Updated_By"), rs.getInt("Customer_ID")
                            , rs.getInt("User_ID"), rs.getInt("Contact_ID"));

                    appointments.add(appointment);
                }
            } catch (SQLException sqlException) {
                sqlException.printStackTrace();
            }



            customerData.setItems(customerList);

                custIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
                custNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
                addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
                postalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
                phoneCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
                createDateCol.setCellValueFactory(new PropertyValueFactory<>("createDate"));
                createdByCol.setCellValueFactory(new PropertyValueFactory<>("createdBy"));
                lastUpdateCol.setCellValueFactory(new PropertyValueFactory<>("lastUpdate"));
                lastUpdatedByCol.setCellValueFactory(new PropertyValueFactory<>("lastUpdatedBy"));
                DivisionIdCol.setCellValueFactory(new PropertyValueFactory<>("divisionId"));


        }
}

