package Controller;

import Helper.JDBC;
import Model.Appointment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.ResourceBundle;

@SuppressWarnings("CanBeFinal")
public class AppointmentMenuController implements Initializable {
    ObservableList<Appointment> appointments = FXCollections.observableArrayList();
    ObservableList<Appointment> filteredAppointments = FXCollections.observableArrayList();
    Parent parent;
    Scene scene;

    @FXML
    private RadioButton AllAppointments;

    @FXML
    private ToggleGroup Appointments;

    @FXML
    private RadioButton appointmentsThisWeek;

    @FXML
    private RadioButton thisMonthRdBt;

    @FXML
    private TableColumn<Appointment, Integer> appointIdCol;

    @FXML
    private TableColumn<Appointment, Integer> contactCol;

    @FXML
    private TableColumn<Appointment, Integer> custIdCol;

    @FXML
    private TableColumn<Appointment, String> descCol;

    @FXML
    private TableColumn<Appointment, Timestamp> endCol;

    @FXML
    private TableColumn<Appointment, String> locationCol;

    @FXML
    private TableColumn<Appointment, Timestamp> startCol;

    @FXML
    private TableColumn<Appointment, String> titleCol;

    @FXML
    private TableColumn<Appointment, String> typeCol;

    @FXML
    private TableColumn<Appointment, Integer> userIdCol;

    @FXML
    private TableView<Appointment> AppointmentData;

    /**
     *
     * @param event Clicking this radiobutton will show all appointments in the tableview
     */
    @FXML
    void OnActionShowAll(ActionEvent event) {

        AppointmentData.setItems(appointments);
        AppointmentData.refresh();
    }

    /**
     *
     * @param event This button makes the tableview only display appointments that are within a month
     */
    @FXML
    void onActionShowThisMonth(ActionEvent event) {
        filteredAppointments.clear();
        for(Appointment appointment: appointments) {
            if (appointment.getStartTime().before(Timestamp.valueOf(LocalDateTime.now().plusMonths(1))) && appointment.getStartTime().after(Timestamp.valueOf(LocalDateTime.now()))) {
                System.out.println("These appointments are within a month! " + appointment.getStartTime());
                filteredAppointments.add(appointment);
                System.out.println(appointment.getAppointmentID() + " " + appointment.getStartTime());
            }
        }
        AppointmentData.setItems(filteredAppointments);
        AppointmentData.refresh();
    }

    /**
     *
     * @param event this button makes the tableview only display appointments that are within a week.
     */
    @FXML
    void onActionShowThisWeek(ActionEvent event) {
        filteredAppointments.clear();
        for(Appointment appointment: appointments) {
            if (appointment.getStartTime().before(Timestamp.valueOf(LocalDateTime.now().plusWeeks(1))) && appointment.getStartTime().after(Timestamp.valueOf(LocalDateTime.now()))) {
                System.out.println("These appointments are within a week! " + appointment.getStartTime());
                filteredAppointments.add(appointment);
            }
        }
        AppointmentData.setItems(filteredAppointments);
        AppointmentData.refresh();

    }

    /**
     *
     * @param event This will check first to make sure that an item in the tableview is selected first. If so, then it will ask for confirmation that you
     *              wish to delete the item, then, if confirmed, it will delete all appointments that are connected to it first then it deletes the customer
     *              record.
     * @throws SQLException
     */
    @FXML
    void OnActionDelete(ActionEvent event) throws SQLException {
        if (AppointmentData.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "You must make a selection in the table first!");
            alert.showAndWait();
            return;
        }
        Alert comAlert = new Alert(Alert.AlertType.CONFIRMATION, "Are you certain you wish to delete this appointment record?");
        comAlert.setTitle("Confirmation Needed");
        Optional<ButtonType> result = comAlert.showAndWait();

        if (result.get() == ButtonType.OK) {
            for (Appointment appointment : appointments) {
                if (appointment.getAppointmentID() == (AppointmentData.getSelectionModel().getSelectedItem().getAppointmentID())) {
                    JDBC.makePreparedStatement("DELETE FROM appointments WHERE Appointment_ID = " + appointment.getAppointmentID(),
                            JDBC.getConnection());
                    PreparedStatement ps = JDBC.getPreparedStatement();
                    ps.executeUpdate();
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Appointment #: " + appointment.getAppointmentID() + " of type " + appointment.getType() + " has been canceled");
                    alert.showAndWait();
                    appointments.remove(appointment);
                }
            }
            AppointmentData.refresh();
        }
    }

    /**
     *
     * @param event Upon, clicking, it will send you to the AddCustomerForm.
     * @throws IOException if there is an IOException, it will be thrown.
     */
    @FXML
    void onActionAdd(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/AddAppointmentForm.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }

    /**
     *
     * @param event Will leave the application.
     */
    @FXML
    void onActionExitApplication(ActionEvent event) { System.exit(0);
    }

    /**
     *
     * @param event Clicking the see reports button will send you to the reports screen.
     * @throws IOException if there is an IOException, it will be thrown.
     */
    @FXML
    void onActionSwitchtoReportView(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/Reports.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event Upon clicking go to customers menu
     * @throws IOException if there is an IOException, it will be thrown.
     */
    @FXML
    void onActionGoToCustomerList(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/CustomerMenu.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     *
     * @param event Will first check to see if an item is selected from the tableview, if so, it will bring you to the update screen.
     * @throws IOException if there is an IOException, it will be thrown.
     */
    @FXML
    void onActionUpdate(ActionEvent event) throws IOException {
        if(AppointmentData.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "You need to make a selection from the table first!");
            alert.showAndWait();
            return;
        }

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View/UpdateAppointment.fxml"));
        loader.load();
        UpdateAppointmentFormController UAFC = loader.getController();

        UAFC.recieveAppointmentInfo(AppointmentData.getSelectionModel().getSelectedItem());

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }


    /**
     *  This initialize method will fill an observable list with the results from the SELECT statement from the appointment table
     *  Also, initializes the tableview with appointments.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            JDBC.makePreparedStatement("SELECT * FROM appointments", JDBC.getConnection());
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                Appointment appointment = new Appointment(rs.getInt("Appointment_ID"), rs.getString("Title"), rs.getString("Description"),
                        rs.getString("Location"), rs.getString("Type"), rs.getTimestamp("Start"), rs.getTimestamp("End"), rs.getTimestamp("Create_Date"),
                        rs.getString("Created_By"), rs.getTimestamp("Last_Update"), rs.getString("Last_Updated_By"), rs.getInt("Customer_ID")
                , rs.getInt("User_ID"), rs.getInt("Contact_ID"));

                appointments.add(appointment);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        AppointmentData.setItems(appointments);

        appointIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        descCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        locationCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        custIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        userIdCol.setCellValueFactory(new PropertyValueFactory<>("userID"));
        contactCol.setCellValueFactory(new PropertyValueFactory<>("contactID"));

    }
}
