Thank you for your purchase of Appointakeep V 1.2!
The purpose of this application is to help businesses manage their appointments with their customers!
The author of this application is me, Seth Andrew Jokinen,
my student email is: sjokine@my.wgu.edu, the current up-to-date version is 1.2
and the date of its release is 1/29/2023.
Built using: Intellij IDEA 2021.1.3 (Community Edition),
The JavaFX is: sdk-17.0.1 and the full JDK SE is 17.0.1
To run the program, simply run the AppointaKeep.exe  and you will be met with the login in screen.

You must give the login screen correct credentials in order to move on to the next screen,
the customer Record’s menu. At the time of a successful log-in, you’ll be notified
if you have a pending appointment within 15 minutes or it will tell you that there is no pending appointments.

The customer records menu has 3 buttons to add, update and delete customer records,
note that updating and deletion require selection of an item in the table.
The other two buttons are to either go to reports or to see the appointments list.
The next screen I will discuss will be the Appointments menu.
This, like the Customer Record menu, has 3 buttons to add, update or delete appointments.
Like before, please make sure to have a selection before attempting to delete or update a record.
Additionally, this menu screen also has a button to go back to the customer menu or to go to the reports menu.

The reports menu has a table view which, on default reflects the monthly and by type report, which will show you all reports by customer ID, type, month and the total of that type for that month.
The second report you can access by selecting the second radio button which is a list of contact schedules.
The final radio button will bring you to a “update tracker” which will show you appointment IDs,
the last time the appointment record was updated, and which user had updated it, along with a customer ID,
the user who last updated that customer record, and the time it was done.
I chose to make my third report the “Update Tracker”
as it will show the last time that appointments, or customer records attached to those appointments were last updated.
Naturally, you would want to confirm with a customer that their information is recent if it has been a while since it was last updated.

The MySQL Connector driver version: mysql-connector-java-8.0.25
