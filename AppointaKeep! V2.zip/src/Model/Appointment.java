package Model;

import java.sql.Timestamp;

/**
 * This is my class for Appointments. This is used to create Appointment objects.
 */
public class Appointment {
    private String title;
    private int appointmentID;
    private int contactID;
    private int customerID;
    private String description;
    private Timestamp startTime;
    private Timestamp endTime;
    private String location;
    private String type;
    private int userID;
    private Timestamp createDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdatedBy;

    /**
     * This is my Appointment constructor.
     * @param appointID This assigns the appointment ID argument to the class field member of a similar name.
     * @param title this assigns the title argument to the class field member of a similar name.
     * @param description this assigns the description argument to the class field member of a similar name.
     * @param location this assigns the location argument to the class field member of a similar name.
     * @param type this assigns the type argument to the class field member of a similar name.
     * @param startTime this assigns the startTime argument to the class field member of a similar name.
     * @param endTime this assigns the endTime argument to the class field member of a similar name.
     * @param createDate this assigns the createDate argument to the class field member of a similar name.
     * @param createdBy this assigns the createdBy argument to the class field member of a similar name.
     * @param lastUpdate this assigns the lastUpdate argument to the class field member of a similar name.
     * @param lastUpdatedBy this assigns the lastUpdateBy argument to the class field member of a similar name.
     * @param customerID this assigns the customerID argument to the class field member of a similar name.
     * @param userID this assigns the userID argument to the class field member of a similar name.
     * @param contactID this assigns the contactID argument to the class field member of a similar name.
     */
    public Appointment( int appointID, String title, String description, String location, String type, Timestamp startTime,
                Timestamp endTime, Timestamp createDate, String createdBy,
                        Timestamp lastUpdate, String lastUpdatedBy, int customerID, int userID,  int contactID) {

        this.title = title;
        this.appointmentID = appointID;
        this.contactID = contactID;
        this.customerID = customerID;
        this.description = description;
        this.startTime = startTime;
        this.endTime = endTime;
        this.location = location;
        this.type   = type;
        this.userID = userID;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;

    }

    /**
     * @return This method returns an appointmentID for a particular instance.
     */
    public int getAppointmentID() {
        return appointmentID;
    }

    /**
     * @param appointmentID This sets a particular instance's appointmentID to a desired value.
     */
    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    /**
     * @return This method returns a Contact ID for a particular instance.
     */
    public int getContactID() {
        return contactID;
    }

    /**
     * @param contact This sets a particular instance's contactID.
     */
    public void setContactID(int contact) {
        contactID = contact;
    }

    /**
     * @return This returns a customerID.
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * @param customerID This sets a customerID to a desired value.
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     * @return returns a description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description Sets a description value.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return returns a start time for an appointment.
     */
    public Timestamp getStartTime() {
        return startTime;
    }

    /**
     * @param startTime Sets a start time of an appointment.
     */
    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    /**
     * @return gets the end time of an appointment.
     */
    public Timestamp getEndTime() {
        return endTime;
    }

    /**
     * @param endTime Sets the end time of an appointment
     */
    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    /**
     * @return a location value.
     */
    public String getLocation() {
        return location;
    }

    /**
     * @param location sets the location value.
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * @return the type value
     */
    public String getType() {
        return type;
    }

    /**
     * @param type sets the type of the Appointment object.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the user ID.
     */
    public int getUserID() {
        return userID;
    }

    /**
     * @param userID Sets the userID.
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * @return gets the title from an appointment object.
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title sets the Title field
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the createDate
     */
    public Timestamp getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate sets the createDate
     */
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the createdBy value
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy sets the createdBy value.
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the lastUpdate value
     */
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    /**
     * @param lastUpdate sets the last update value
     */
    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /**
     * @return the lastUpdatedBy value
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * @param lastUpdatedBy sets the lastUpdatedBy value
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
}
