package Model;

import java.sql.Timestamp;

/**
 * This class makes UpdateTrackerReport objects and is the class that makes the third reports.
 */
public class UpdateTrackerReports {
    private int appointmentID;
    private String appointUpdateBy;
    private Timestamp appointUpdateTime;
    private int custID;
    private String custUpdateBy;
    private Timestamp custUpdateTime;

    /**
     * This is the constructor for my UpdateTrackerReports class.
     * @param appointmentID this assigns the appointmentID parameter to the class field member of a similar name.
     * @param appointUpdateBy this assigns the appointUpdateBy parameter to the class field member of a similar name.
     * @param appointUpdateTime this assigns the appointUpdateTime parameter to the class field member of a similar name.
     * @param custID this assigns the custID parameter to the class field member of a similar name.
     * @param custUpdateBy this assigns the custUpdateBy parameter to the class field member of a similar name.
     * @param custUpdateTime this assigns the custUpdateTime parameter to the class field member of a similar name.
     */
    public UpdateTrackerReports(int appointmentID, String appointUpdateBy, Timestamp appointUpdateTime, int custID, String custUpdateBy, Timestamp custUpdateTime) {
        this.appointmentID = appointmentID;
        this.appointUpdateBy = appointUpdateBy;
        this.appointUpdateTime = appointUpdateTime;
        this.custID = custID;
        this.custUpdateBy = custUpdateBy;
        this.custUpdateTime = custUpdateTime;
    }

    /**
     * @return appointmentID
     */
    public int getAppointmentID() {
        return appointmentID;
    }

    /**
     * @param appointmentID sets the appointmentID
     */
    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    /**
     * @return the last person to update this appointment.
     */
    public String getAppointUpdateBy() {
        return appointUpdateBy;
    }

    /**
     * @param appointUpdateBy sets the last person to update this appointment.
     */
    public void setAppointUpdateBy(String appointUpdateBy) {
        this.appointUpdateBy = appointUpdateBy;
    }

    /**
     * @return the last time the appointment was updated.
     */
    public Timestamp getAppointUpdateTime() {
        return appointUpdateTime;
    }

    /**
     * @param appointUpdateTime sets the last time the appointment was updated.
     */
    public void setAppointUpdateTime(Timestamp appointUpdateTime) {
        this.appointUpdateTime = appointUpdateTime;
    }

    /**
     * @return the customerID
     */
    public int getCustID() {
        return custID;
    }

    /**
     * @param custID sets the custID
     */
    public void setCustID(int custID) {
        this.custID = custID;
    }

    /**
     * @return the person that last updated this customer record.
     */
    public String getCustUpdateBy() {
        return custUpdateBy;
    }

    /**
     * @param custUpdateBy sets the last person to update this customer record.
     */
    public void setCustUpdateBy(String custUpdateBy) {
        this.custUpdateBy = custUpdateBy;
    }

    /**
     * @return the last time the customer record was updated.
     */
    public Timestamp getCustUpdateTime() {
        return custUpdateTime;
    }

    /**
     * @param custUpdateTime sets the last time the customer field was updated.
     */
    public void setCustUpdateTime(Timestamp custUpdateTime) {
        this.custUpdateTime = custUpdateTime;
    }
}
