package Model;

import java.sql.Timestamp;

/**
 * This is the FirstLevelDivisions class which creates objects that hold the following fields.
 */
public class FirstLevelDivisions {
    private int division_id;
    private String division;
    private Timestamp createDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdateBy;
    private int countryID;

    /**
     * This is the FirstLevelDivisions constructor.
     * @param division_id this assigns the division_id parameter to the class field member of a similar name.
     * @param division this assigns the division parameter to the class field member of a similar name.
     * @param createDate this assigns the createDate parameter to the class field member of a similar name.
     * @param createdBy this assigns the createBy parameter to the class field member of a similar name.
     * @param lastUpdate this assigns the lastUpdate parameter to the class field member of a similar name.
     * @param lastUpdateBy this assigns the lastUpdateBy parameter to the class field member of a similar name.
     * @param countryID this assigns the countryID parameter to the class field member of a similar name.
     */
    public FirstLevelDivisions(int division_id, String division, Timestamp createDate, String createdBy,
                               Timestamp lastUpdate, String lastUpdateBy, int countryID) {
        this.division_id = division_id;
        this.division = division;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = lastUpdateBy;
        this.countryID = countryID;
    }

    /**
     * @return the division_ID
     */
    public int getDivision_id() {
        return division_id;
    }

    /**
     * @param division_id sets the division_id
     */
    public void setDivision_id(int division_id) {
        this.division_id = division_id;
    }

    /**
     * @return the Division
     */
    public String getDivision() {
        return division;
    }

    /**
     * @param division sets the Division
     */
    public void setDivision(String division) {
        this.division = division;
    }

    /**
     * @return the createDate
     */
    public Timestamp getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate sets the createDate
     */
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the createdBy field
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy setCreatedBy field
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the lastUpdate
     */
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    /**
     * @param lastUpdate sets the lastUpdate
     */
    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /**
     * @return gets LastUpdatedBy field
     */
    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    /**
     * @param lastUpdateBy sets lastUpdatedBy field
     */
    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    /**
     * @return the countryID
     */
    public int getCountryID() {
        return countryID;
    }

    /**
     * @param countryID sets the countryID
     */
    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    /**
     * @return the name of the division
     */
    @Override
    public String toString() {
        return division;
    }


}
