package Model;

import java.sql.Timestamp;

/**
 * This class creates User objects.
 */
public class User {
    private int userID;
    private String userName;
    private String password;
    private Timestamp dateCreated;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdateBy;

    /**
     * This is the constructor for the User class.
     * @param userID this assigns the userID parameter to the class field member of a similar name.
     * @param userName this assigns the userName parameter to the class field member of a similar name.
     * @param password this assigns the password parameter to the class field member of a similar name.
     * @param dateCreated this assigns the dateCreated parameter to the class field member of a similar name.
     * @param createdBy this assigns the createdBy parameter to the class field member of a similar name.
     * @param lastUpdate this assigns the lastUpdate parameter to the class field member of a similar name.
     * @param lastUpdateBy this assigns the lastUpdateBy parameter to the class field member of a similar name.
     */
    public User(int userID, String userName, String password, Timestamp dateCreated,
                String createdBy, Timestamp lastUpdate, String lastUpdateBy) {
        this.userID = userID;
        this.userName = userName;
        this.password = password;
        this.dateCreated = dateCreated;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = lastUpdateBy;
    }

    /**
     * @return the userID
     */
    public int getUserID() {
        return userID;
    }

    /**
     * @param userID sets the userID
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * @return userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName sets the userName
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password sets the password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return gets the DateCreated field.
     */
    public Timestamp getDateCreated() {
        return dateCreated;
    }

    /**
     * @param dateCreated sets the dateCreated
     */
    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * @return the getCreatedBy field
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy  sets the createdBy field
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return lastUpdate field
     */
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    /**
     * @param lastUpdate sets the lastUpdate field to the given argument.
     */
    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /**
     * @return the lastUpdateBy field
     */
    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    /**
     * @param lastUpdateBy sets the lastUpdateBy field
     */
    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

}
