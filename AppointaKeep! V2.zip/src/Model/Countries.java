package Model;

import java.sql.Timestamp;

/**
 * This is my Countries class which will create Country objects.
 */
public class Countries {
    private int countryID;
    private String country;
    private Timestamp dateTime;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdateBy;

    /**
     * This is my constructor for my Countries class.
     * @param countryID this assigns the countryID parameter to the class field member of a similar name.
     * @param country this assigns the country parameter to the class field member of a similar name.
     * @param dateTime this assigns the dateTime parameter to the class field member of a similar name.
     * @param createdBy this assigns the createdBy parameter to the class field member of a similar name.
     * @param lastUpdate this assigns the lastUpdate parameter to the class field member of a similar name.
     * @param lastUpdateBy this assigns the lastUpdateBy parameter to the class field member of a similar name.
     */
    public Countries(int countryID, String country, Timestamp dateTime, String createdBy, Timestamp lastUpdate, String lastUpdateBy) {
        this.countryID = countryID;
        this.country = country;
        this.dateTime = dateTime;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = lastUpdateBy;
    }

    /**
     * @return get the countryID
     */
    public int getCountryID() {
        return countryID;
    }

    /**
     * @param countryID sets the countryID
     */
    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    /**
     * @return the country(name)
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country sets the country(name)
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the DateTime
     */
    public Timestamp getDateTime() {
        return dateTime;
    }

    /**
     *
     * @param dateTime sets the dateTime
     */
    public void setDateTime(Timestamp dateTime) {
        this.dateTime = dateTime;
    }

    /**
     * @return the getCreatedBy for an object.
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy sets the createdBy for an country
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the lastUpdate for Country
     */
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    /**
     * @param lastUpdate sets the lastUpdate field.
     */
    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /**
     * @return get lastUpdateBy field
     */
    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    /**
     * @param lastUpdateBy sets the lastUpdateBy field.
     */
    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    /**
     * @return the country name.
     */
    @Override
    public String toString() {
        return country;

    }
}
