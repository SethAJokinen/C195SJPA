package Model;

import java.sql.Timestamp;

/**
 * This is my Customer class which makes customer objects.
 */
public class Customer {

    private int divisionId;
    private String address;
    private Timestamp createDate;
    private String createdBy;
    private int customerID;
    private String customerName;
    private Timestamp lastUpdate;
    private String lastUpdatedBy;
    private String phoneNumber;
    private String postalCode;

    /**
     * This is the constructor for the Customer class.
     * @param customerID this assigns the customerID parameter to the class field member of a similar name.
     * @param customerName this assigns the customerName parameter to the class field member of a similar name.
     * @param address this assigns the address parameter to the class field member of a similar name.
     * @param postalCode this assigns the postalCode parameter to the class field member of a similar name.
     * @param phoneNumber this assigns the phoneNumber parameter to the class field member of a similar name.
     * @param createDate this assigns the createDate parameter to the class field member of a similar name.
     * @param createdBy this assigns the createdBy parameter to the class field member of a similar name.
     * @param lastUpdate this assigns the lastUpdate parameter to the class field member of a similar name.
     * @param lastUpdatedBy this assigns the lastUpdateBy parameter to the class field member of a similar name.
     * @param divisionId this assigns the divisionId parameter to the class field member of a similar name.
     */
    public Customer(int customerID, String customerName, String address, String postalCode, String phoneNumber,
                    Timestamp createDate, String createdBy, Timestamp lastUpdate, String lastUpdatedBy, int divisionId) {
        this.divisionId = divisionId;
        this.address = address;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.customerID = customerID;
        this.customerName = customerName;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.phoneNumber = phoneNumber;
        this.postalCode = postalCode;
    }

    /**
     * @return  the DivisionID
     */
    public int getDivisionId() {
        return divisionId;
    }

    /**
     * @param divisionId sets the divisionID
     */
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }

    /**
      * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address sets the address value
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the createDate
     */
    public Timestamp getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate sets the createDate
     */
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    /**
     * @return getCreatedBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy sets the createdBy field.
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return customerID
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * @param customerID sets the customerID
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     * @return the customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * @param customerName sets the customerName
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * @return the lastUpdate
     */
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    /**
     * @param lastUpdate sets the last update field.
     */
    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /**
     * @return the lastUpdatedBy field.
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * @param lastUpdatedBy set LastUpdatedBy field.
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /**
     * @return the phonenumber of a customer.
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     *
     * @param phoneNumber sets the phonenumber for a customer.
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * @param postalCode sets the postalCode value
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
}
