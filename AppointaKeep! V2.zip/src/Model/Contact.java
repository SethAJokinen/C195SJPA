package Model;

/**
 * This is my contact class which makes contact objects.
 */
public class Contact {
        private int contactID;
        private String contactName;
        private String email;

    /**
     * This is the Contact Class constructor.
     * @param contactID this assigns the contactID argument to the class field member of a similar name.
     * @param contactName this assigns the contactName argument to the class field member of a similar name.
     * @param email this assigns the email argument to the class field member of a similar name.
     */
    public Contact(int contactID, String contactName, String email) {
        this.contactID = contactID;
        this.contactName = contactName;
        this.email = email;
    }

    /**
     * @return the contactID
     */
    public int getContactID() {
        return contactID;
    }

    /**
     * @param contactID sets the contactID
     */
    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    /**
     * @return the contactName
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * @param contactName sets the name of the contact for an object.
     */
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    /**
     * @return the email for an contact object
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email sets the email for a contact object
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the contactName
     */
    @Override
    public String toString() {
        return contactName;
    }
}
