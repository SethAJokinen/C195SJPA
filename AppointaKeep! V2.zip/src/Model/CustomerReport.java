package Model;

import java.sql.Timestamp;
import java.time.Month;

/**
 * This is the CustomerReport class which is responsible for the creation of CustomerReport objects.
 */
public class CustomerReport {
    private int custID;
    private String type;
    private Month Start;
    private int count;

    /**
     * This is the constructor for the CustomerReport class.
     * @param custID this assigns the custID parameter to the class field member of a similar name.
     * @param type this assigns the type parameter to the class field member of a similar name.
     * @param start this assigns the start parameter to the class field member of a similar name.
     * @param count this assigns the end parameter to the class field member of a similar name.
     */
    public CustomerReport(int custID, String type, Month start, int count) {
        this.custID = custID;
        this.type = type;
        Start = start;
        this.count = count;
    }

    /**
     * @return the custID
     */
    public int getCustID() {
        return custID;
    }

    /**
     * @param custID sets the custID
     */
        public void setCustID(int custID) {
            this.custID = custID;
        }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type sets the type for a CustomerReport
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the getStart() Month
     */
    public Month getStart() {
        return Start;
    }

    /**
     * @param start sets the start month.
     */
    public void setStart(Month start) {
        Start = start;
    }

    /**
     * @return gets the count
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count sets the count
     */
    public void setCount(int count) {
        this.count = count;
    }
}
