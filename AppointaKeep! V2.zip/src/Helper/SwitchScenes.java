package Helper;

import java.io.IOException;

/**
 * This interface was created to produce lambdas expressions switch screens.
 */
public interface SwitchScenes {
    /**
     *
     * @param s This parameter is supposed to take a filepath, particularly one in the View package.
     * @throws IOException //thrown if an IOException is reached.
     */
    void switchScreen(String s) throws IOException;
}
