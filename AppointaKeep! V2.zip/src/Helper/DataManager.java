package Helper;

import Model.Countries;
import Model.FirstLevelDivisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Timestamp;

/**
 * This class is responsible for managing certain data fields like a userName, createDate and a countries ObservableList.
 */
public class DataManager {
    public static String userName;
    public static Timestamp createDate;

    public static ObservableList<Countries> countriesList = FXCollections.observableArrayList();
}
