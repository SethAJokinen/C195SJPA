package Helper;

import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * This interface was created to produce lambda expressions
 */
public interface TimeZoneConverter {
    /**
     * @param zoneId this class takes a zoneiD for the purpose of switching the time zones.
     * @return a LocalDateTime object
     */
    LocalDateTime timeConversion (ZoneId zoneId);
}
